<?php include "../../inc/myconnect.php";?>
<?php include "../../inc/myfunction.php";?>
<?php
if ( isset( $_GET[ 'bangcapid' ] ) ) {
//	$id = '';
//	$i = 1;
//	foreach ( $_GET[ 'bangcapid' ] as $names ) {
//		if ( $count > $i )
//			$id = $id . $names . ",";
//		else
//			$id = $id . $names;
//		$i++;
//	}
	$rsGetHeSo = mysqli_fetch_assoc( mysqli_query( $dbc, 
		"select max(heso) as 'heso' from bangcap where bang_cap_id in ({$_GET['bangcapid']})" ) );
	$hesonNew = $rsGetHeSo[ 'heso' ];
	echo $hesonNew;
}
?>