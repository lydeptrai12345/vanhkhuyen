<!-- Header-->
<?php include "admin-header.php";?>
<!-- End header-->


<!-- Page content-->
<?php include "admin-dashboard-content.php";?>
<!-- End page content-->


<!-- Footer-->
<?php include "admin-footer.php";?>
<!-- End footer-->