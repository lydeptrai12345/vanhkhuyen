<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
</head>
<body>

<div class="container">
  
  <div class="panel-group" id="accordion">
    <div class="panel panel-default">
      <div class="panel-heading" data-target="#collapse1" data-toggle="collapse" data-parent="#accordion">
        <h4 class="panel-title">
          Quản lý tin tức
        </h4>
      </div>
      <div id="collapse1" class="panel-collapse collapse">
        <ul class="list-group">
          <li class="list-group-item"><a class="cus-collapse-item" href="#">One</a></li>
          <li class="list-group-item"><a class="cus-collapse-item" href="#">One</a></li>
          <li class="list-group-item"><a class="cus-collapse-item" href="#">One</a></li>
        </ul>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading" data-target="#collapse2" data-toggle="collapse" data-parent="#accordion">
        <h4 class="panel-title">
          Quản lý thiết bị
        </h4>
      </div>
      <div id="collapse2" class="panel-collapse collapse">
        <ul class="list-group">
          <li class="list-group-item"><a class="cus-collapse-item" href="#">One</a></li>
          <li class="list-group-item"><a class="cus-collapse-item" href="#">One</a></li>
          <li class="list-group-item"><a class="cus-collapse-item" href="#">One</a></li>
        </ul>
      </div>
    </div>
    <div class="panel panel-default">
		<a href="#" style="text-decoration: none; display: block;line-height: 1.1;color:black;background:#f5f5f5" >
      <div class="panel-heading" data-target="#collapse4" data-toggle="collapse" data-parent="#accordion">
        <div class="panel-title">
          Collapsible Group 3
        </div>
      </div>
      </a>
		<div id="collapse4" class="panel-collapse collapse">
    </div>
		</div>
    <div class="panel panel-default">
      <div class="panel-heading" data-target="#collapse3" data-toggle="collapse" data-parent="#accordion">
        <h4 class="panel-title">
          Collapsible Group 4
        </h4>
      </div>
      <div id="collapse3" class="panel-collapse collapse">
        <ul class="list-group">
          <li class="list-group-item"><a class="cus-collapse-item" href="#">One</a></li>
          <li class="list-group-item"><a class="cus-collapse-item" href="#">One</a></li>
          <li class="list-group-item"><a class="cus-collapse-item" href="#">One</a></li>
        </ul>
      </div>
    </div>
  </div> 
</div>
<label class="aaa">Mutiple select list (hold shift to select more than one):</label>
<select multiple="multiple" class="form-control" style="width: 30%;">
  <option value="0">Trung cấp</option>
  <option value="1">Cao đẳng</option>
  <option value="2">Đại học</option>
  <option value="3">Thạc sĩ</option>
  <option value="4">Tiến sĩ</option>
</select>
</div>
<style>
  a{    
    text-decoration: none !important;
  }
  a:hover{
    color:inherit;
  }
  .select2-results__option[aria-selected=true] {
   position: relative;
  }
  .select2-results__option[aria-selected=true]::after {
    content: '\e013';
    position: absolute;
    top: 9px;
    right: 5%;
    font-family: "Glyphicons Halflings";
    line-height: 1;
    font-size: 13px;
    -webkit-font-smoothing: antialiased;
    color: #09ab09
  }
  .select2-selection__choice{
    background-color: #66b2cc !important;
    border: 1px solid #66b2cc !important;
    color: white
  }
  .select2-selection__choice__remove:hover{
    color: #ddd !important;
  }
  .select2-selection__choice__remove{
    color: white !important;
    padding-right: 1px;  
  }


  .panel-heading{
    cursor: pointer;
    user-select: none;
  }
  .panel-heading:hover{
    background: darkgrey;
    color: white;
    box-shadow: 0 0 30px 0 rgba(158, 163, 167, 0.5);
  }  
  .panel-heading[aria-expanded=true]{
  background:-webkit-linear-gradient(left,#66a7cf 5%,#66bcca);
  color: white;
  }
	.panel-heading[aria-expanded=false]{
  color: black;
  }


  .cus-collapse-item{
    display: block;
    color: black;
  }
</style>
<script>
$(document).ready(function() {
    $('select').select2({})
        .on("select2:select", function(e) {
          setScrollTopForDropDown(e);
        })
        .on("select2:selecting", function(e) {
          setScrollTopForSelectBox(e);
        })
        .on("select2:unselect", function(e) {
          setScrollTopForDropDown(e);
        })
        .on("select2:unselecting", function(e) {
          $(this).data("state", "unselected");
          setScrollTopForSelectBox(e);
        })
        .on("select2:open", function(e) {
          if ($(this).data("state") === "unselected") {
            $(this).removeData("state");
            $(this).select2("close");
          }
        });

      function setScrollTopForDropDown(e){
        $(".select2-results__options").scrollTop($(e.currentTarget).data("scrolltop"));
      };

      function setScrollTopForSelectBox(e){
        $(e.currentTarget).data("scrolltop", $(".select2-results__options").scrollTop());
      };
});
</script>   
</body>
</html>



